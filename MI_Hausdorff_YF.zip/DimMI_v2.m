function dim = DimMI_v2(centroid, IM)
% function DimMI is to calculate dimension of the neighbouring region for
% Hausdorff measurement by mutual information
% 
% Input Variables:
% centroid - centroid array, the number of elements of the array is the
%            cluster number.
% IM - input image for clustering
%
% Output Variables:
% dim - dimension of the neighbouring region for Hausdorff measurement, 
%       [size(IM), length(centroid)], each element is the size of the
%       neighbor region
% 
% Record of Revision
% Feb-19-2016===XX===Original Codes
% Feb-26-2016===YF===Add comments
% Feb-28-2016===YF===Change the region selection criteria, highest MI-3

% initializing for mutual information caluclation with different window
% size: 3x3, 5x5, 7x7
C = zeros(3);
D = zeros(3);
E = zeros(5);
F = zeros(5);
G = zeros(7);
H = zeros(7);
% initializing mutual information array
h3 = zeros(size(IM,1),size(IM,2),length(centroid));
h5 = zeros(size(IM,1),size(IM,2),length(centroid));
h7 = zeros(size(IM,1),size(IM,2),length(centroid));
dim = zeros(size(IM,1),size(IM,2),length(centroid));

% mutual information calculation for each neighbor region size
% MI 3D array for each centroid with size=3x3
for kk = 1:length(centroid)
    for ii = 1:size(IM,1)
        for jj = 1:size(IM,2)
            if ii==1 && jj==1 % left upper corner
                C(2:3,2:3) = IM(ii:ii+1,jj:jj+1);
                D(2:3,2:3) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii==1 && jj==size(IM,2) % right upper corner
                C(2:3,1:2) = IM(ii:ii+1,jj-1:jj);
                D(2:3,1:2) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii==size(IM,1) && jj==1 % left bottom corner
                C(1:2,2:3) = IM(ii-1:ii,jj:jj+1);
                D(1:2,2:3) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii==size(IM,1) && jj==size(IM,2) % right bottom corner
                C(1:2,1:2) = IM(ii-1:ii,jj-1:jj);
                D(1:2,1:2) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii==1 && jj>1 && jj<size(IM,2) % upper central line
                C(2:3,:) = IM(ii:ii+1,jj-1:jj+1);
                D(2:3,:) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii==size(IM,1) && jj>1 && jj<size(IM,2) % bottom central line
                C(1:2,:) = IM(ii-1:ii,jj-1:jj+1);
                D(1:2,:) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii>1 && ii<size(IM,1) && jj==1 % left central line
                C(:,2:3) = IM(ii-1:ii+1,jj:jj+1);
                D(:,2:3) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            elseif ii>1 && ii<size(IM,1) && jj==size(IM,2) % right central line
                C(:,1:2) = IM(ii-1:ii+1,jj-1:jj);
                D(:,1:2) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            else
                C(:,:) = IM(ii-1:ii+1,jj-1:jj+1); % central region
                D(:,:) = centroid(kk);
                h3(ii,jj,kk) = estmutualinfo(estpab(C, D));
            end
        end
    end
end

% MI 3D array for each centroid with size=5x5
for kk = 1:length(centroid)
    for ii = 1:size(IM,1)
        for jj = 1:size(IM,2)
            if ii<=2 && jj<=2
                E(4-ii:5,4-jj:5) = IM(1:ii+2,1:jj+2);
                F(4-ii:5,4-jj:5) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii<=2 && jj>=size(IM,2)-1
                E(4-ii:5,1:size(IM,2)-jj+3) = IM(1:ii+2,jj-2:size(IM,2));
                F(4-ii:5,1:size(IM,2)-jj+3) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii>=size(IM,1)-1 && jj<=2
                E(1:size(IM,1)-ii+3,4-jj:5) = IM(ii-2:size(IM,1),1:jj+2);
                F(1:size(IM,1)-ii+3,4-jj:5) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii>=size(IM,1)-1 && jj>=size(IM,2)-1
                E(1:size(IM,1)-ii+3,1:size(IM,2)-jj+3) = IM(ii-2:size(IM,1),jj-2:size(IM,2));
                F(1:size(IM,1)-ii+3,1:size(IM,2)-jj+3) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii<=2 && jj>2 && jj<size(IM,2)-1
                E(4-ii:5,:) = IM(1:ii+2,jj-2:jj+2);
                F(4-ii:5,:) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii>=size(IM,1)-1 && jj>2 && jj<size(IM,2)-1
                E(1:size(IM,1)-ii+3,:) = IM(ii-2:size(IM,1),jj-2:jj+2);
                F(1:size(IM,1)-ii+3,:) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii>2 && ii<size(IM,1)-1 && jj<=2
                E(:,4-jj:5) = IM(ii-2:ii+2,1:jj+2);
                F(:,4-jj:5) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            elseif ii>2 && ii<size(IM,1)-1 && jj>=size(IM,2)-1
                E(:,1:size(IM,2)-jj+3) = IM(ii-2:ii+2,jj-2:size(IM,2));
                F(:,1:size(IM,2)-jj+3) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            else
                E(:,:) = IM(ii-2:ii+2,jj-2:jj+2);
                F(:,:) = centroid(kk);
                h5(ii,jj,kk) = estmutualinfo(estpab(E, F));
            end
        end
    end
end

% MI 3D array for each centroid with size=7x7
for kk = 1:length(centroid)
    for ii = 1:size(IM,1)
        for jj = 1:size(IM,2)
            if ii<=3 && jj<=3
                G(5-ii:7,5-jj:7) = IM(1:ii+3,1:jj+3);
                H(5-ii:7,5-jj:7) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii<=3 && jj>=size(IM,2)-2
                G(5-ii:7,1:size(IM,2)-jj+4) = IM(1:ii+3,jj-3:size(IM,2));
                H(5-ii:7,1:size(IM,2)-jj+4) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii>=size(IM,1)-2 && jj<=3
                G(1:size(IM,1)-ii+4,5-jj:7) = IM(ii-3:size(IM,1),1:jj+3);
                H(1:size(IM,1)-ii+4,5-jj:7) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii>=size(IM,1)-2 && jj>=size(IM,2)-2
                G(1:size(IM,1)-ii+4,1:size(IM,2)-jj+4) = IM(ii-3:size(IM,1),jj-3:size(IM,2));
                H(1:size(IM,1)-ii+4,1:size(IM,2)-jj+4) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii<=3 && jj>3 && jj<size(IM,2)-2
                G(5-ii:7,:) = IM(1:ii+3,jj-3:jj+3);
                H(5-ii:7,:) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii>=size(IM,1)-2 && jj>3 && jj<size(IM,2)-2
                G(1:size(IM,1)-ii+4,:) = IM(ii-3:size(IM,1),jj-3:jj+3);
                H(1:size(IM,1)-ii+4,:) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii>3 && ii<size(IM,1)-2 && jj<=3
                G(:,5-jj:7) = IM(ii-3:ii+3,1:jj+3);
                H(:,5-jj:7) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            elseif ii>3 && ii<size(IM,1)-2 && jj>=size(IM,2)-2
                G(:,1:size(IM,2)-jj+4) = IM(ii-3:ii+3,jj-3:size(IM,2));
                H(:,1:size(IM,2)-jj+4) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            else
                G(:,:) = IM(ii-3:ii+3,jj-3:jj+3);
                H(:,:) = centroid(kk);
                h7(ii,jj,kk) = estmutualinfo(estpab(G, H));
            end
        end
    end
end

% neighbor region selection based on MI 3D array for each size
for ii = 1:size(IM,1)
    for jj = 1:size(IM,2)
        for kk = 1:length(centroid)
            if h7(ii,jj,kk)==max([h3(ii,jj,kk),h5(ii,jj,kk),h7(ii,jj,kk)])
                dim(ii,jj,kk) = 5;
            elseif h3(ii,jj,kk)==min([h3(ii,jj,kk),h5(ii,jj,kk),h7(ii,jj,kk)])
                dim(ii,jj,kk) = 3;
            else
                dim(ii,jj,kk) = 3;
            end
        end
    end
end


