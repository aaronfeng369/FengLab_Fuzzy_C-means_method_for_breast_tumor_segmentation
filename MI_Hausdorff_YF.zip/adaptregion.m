%h: Intuitively, mutual information measures the information that X and Y share: 
% it measures how much knowing one of these variables reduces uncertainty about the other.
% For example, if X and Y are independent, then knowing X does not give any information 
% about Y and vice versa, so their mutual information is zero. At the other extreme, 
% if X is a deterministic function of Y and Y is a deterministic function of X then all 
% information conveyed by X is shared with Y: knowing X determines the value of Y and vice versa.
% As a result, in this case the mutual information is the same as the uncertainty contained in Y (or X) alone, 
% namely the entropy of Y (or X). Moreover, this mutual information is the same as the 
% entropy of X and as the entropy of Y. (A very special case of this is when X and Y are the same random variable.)

% Mutual information is a measure of the inherent dependence expressed in the joint distribution
% of X and Y relative to the joint distribution of X and Y under the assumption of independence. 
% Mutual information therefore measures dependence in the following sense: I(X; Y) = 0 
% if and only if X and Y are independent random variables. This is easy to see in one direction: 
% if X and Y are independent, then p(x,y) = p(x) p(y), and therefore:

% b = [2 1 2 1 1]';
% a = [1 2 1 2 1]';
load('N:\Suda Research\ImSeg\ICBEB2015\figures\brainT1\brainT1_v2.mat');

[p12, p1, p2] = estpab(brain(200:205, 200:205),brain(205:210, 205:210));
h = estmutualinfo(p12,p1,p2);