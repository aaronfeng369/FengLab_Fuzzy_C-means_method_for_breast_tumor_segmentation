function DistH = ImHausdorff_v5(IM, centroid)
% function ImHausdorff is to calucate ImHausdorff distance between two
% images. The distance was defined between the neighbor region around each
% pixel.
% 
% Input Variables:
% IM - input image
% centroid - centroid array, the number of elements of the array is the
%            cluster number
%
% Output Variables:
% DistH - Hausdorff distance
% 
% Record of Revision
% Apr-13-2015===YF===Original Codes
% Jan-29-2016===XX===Add dim input
% Jan-31-2016===XX===Modify dim as a matrix
% Feb-28-2016===XX===Dim yield by mutual information

% initialzing
% dim = DimMI(centroid, IM); % for max MI, set region to 7
dim = DimMI_v2(centroid, IM); % for max MI, set region to 3

half = uint8(floor(0.5*dim));
im1 = IM;
DistH = zeros(size(IM,1),size(IM,2),length(centroid));

for kk = 1:length(centroid)
    im2 = ones(size(IM,1),size(IM,2))*centroid(kk);
for ii = 1:size(IM,1)
    for jj = 1:size(IM,2)
      if half(ii,jj,kk)==1
        if ii==1 && jj==1 % upper left
            A = im1(1:ii+1,1:jj+1);
            B = im2(1:ii+1,1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii==size(IM,1) && jj==1 % lower left
            A = im1(ii-1:size(IM,1), 1:jj+1);
            B = im2(ii-1:size(IM,1), 1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii==1 && jj==size(IM,2) % upper right
            A = im1(1:ii+1,jj-1:size(IM,2));
            B = im2(1:ii+1,jj-1:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii==size(IM,1) && jj==size(IM,2) % lower right
            A = im1(ii-1:size(IM,1), jj-1:size(IM,2)); 
            B = im2(ii-1:size(IM,1), jj-1:size(IM,2)); 
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>1 && ii<size(IM,1) && jj==1 % left line
            A = im1(ii-1:ii+1, 1:jj+1);
            B = im2(ii-1:ii+1, 1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>1 && ii<size(IM,1) && jj==size(IM,2) % right line
            A = im1(ii-1:ii+1, jj-1:size(IM,2));
            B = im2(ii-1:ii+1, jj-1:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii==1 && jj>1 && jj<size(IM,2) % top line
            A = im1(1:ii+1, jj-1:jj+1);
            B = im2(1:ii+1, jj-1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii==size(IM,1) && jj>1 && jj<size(IM,2) % bottom line
            A = im1(ii-1:size(IM,1), jj-1:jj+1);
            B = im2(ii-1:size(IM,1), jj-1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        else
            A = im1(ii-1:ii+1, jj-1:jj+1); % all center parts
            B = im2(ii-1:ii+1, jj-1:jj+1);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        end  
      elseif half(ii,jj,kk)==2
        if ii<=2 && jj<=2 % upper left
            A = im1(1:ii+2,1:jj+2);
            B = im2(1:ii+2,1:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-1 && jj<=2 % lower left
            A = im1(ii-2:size(IM,1), 1:jj+2);
            B = im2(ii-2:size(IM,1), 1:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii<=2 && jj>=size(IM,2)-1 % upper right
            A = im1(1:ii+2,jj-2:size(IM,2));
            B = im2(1:ii+2,jj-2:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-1 && jj>=size(IM,2)-1 % lower right
            A = im1(ii-2:size(IM,1), jj-2:size(IM,2)); 
            B = im2(ii-2:size(IM,1), jj-2:size(IM,2)); 
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>2 && ii<size(IM,1)-1 && jj<=2 % left line
            A = im1(ii-2:ii+2, 1:jj+2);
            B = im2(ii-2:ii+2, 1:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>2 && ii<size(IM,1)-1 && jj>=size(IM,2)-1 % right line
            A = im1(ii-2:ii+2, jj-2:size(IM,2));
            B = im2(ii-2:ii+2, jj-2:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii<=2 && jj>2 && jj<size(IM,2)-1 % top line
            A = im1(1:ii+2, jj-2:jj+2);
            B = im2(1:ii+2, jj-2:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-1 && jj>2 && jj<size(IM,2)-1 % bottom line
            A = im1(ii-2:size(IM,1), jj-2:jj+2);
            B = im2(ii-2:size(IM,1), jj-2:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        else
            A = im1(ii-2:ii+2, jj-2:jj+2); % all center parts
            B = im2(ii-2:ii+2, jj-2:jj+2);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        end
        
      else 
        if ii<=3 && jj<=3 % upper left
            A = im1(1:ii+3,1:jj+3);
            B = im2(1:ii+3,1:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-2 && jj<=3 % lower left
            A = im1(ii-3:size(IM,1), 1:jj+3);
            B = im2(ii-3:size(IM,1), 1:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii<=3 && jj>=size(IM,2)-2 % upper right
            A = im1(1:ii+3,jj-3:size(IM,2));
            B = im2(1:ii+3,jj-3:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-2 && jj>=size(IM,2)-2 % lower right
            A = im1(ii-3:size(IM,1), jj-3:size(IM,2)); 
            B = im2(ii-3:size(IM,1), jj-3:size(IM,2)); 
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>3 && ii<size(IM,1)-2 && jj<=3 % left line
            A = im1(ii-3:ii+3, 1:jj+3);
            B = im2(ii-3:ii+3, 1:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>3 && ii<size(IM,1)-2 && jj>=size(IM,2)-2 % right line
            A = im1(ii-3:ii+3, jj-3:size(IM,2));
            B = im2(ii-3:ii+3, jj-3:size(IM,2));
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii<=3 && jj>3 && jj<size(IM,2)-2 % top line
            A = im1(1:ii+3, jj-3:jj+3);
            B = im2(1:ii+3, jj-3:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        elseif ii>=size(IM,1)-2 && jj>2 && jj<size(IM,2)-2 % bottom line
            A = im1(ii-3:size(IM,1), jj-3:jj+3);
            B = im2(ii-3:size(IM,1), jj-3:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        else
            A = im1(ii-3:ii+3, jj-3:jj+3); % all center parts
            B = im2(ii-3:ii+3, jj-3:jj+3);
            DistH(ii,jj,kk) = Hausdorff(A, B);
        end
      end
    end
end
end
