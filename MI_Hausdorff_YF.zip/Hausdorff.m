function DistH = Hausdorff(A, B)
% function Hausdorff is to calculate Hausdorff distance between two matrix
% array A and B.  We take the value as the distance measured from  central
% pixel.
% 
% Input Variables:
% A, B - matrix array, A and B are defined to have the same dimension
% 
% Output Variables:
% DistH - Hausdorff distance
% 
% Record of Revision
% Apr-10-2015===HG,YF===Original Codes
% Apr-13-2015===YF===Modify for general matrix input
HA = zeros(size(A,1),size(A,2));
HB = zeros(size(A,1),size(A,2));
for ii=1:size(A,1)
    for jj=1:size(A,2)
        CA=abs(A-B(ii,jj));
        CB=abs(B-A(ii,jj));
        HA(ii,jj)=min(CA(:));
        HB(ii,jj)=min(CB(:));
    end
end
DistH = max(max(HA(:)),max(HB(:)));
